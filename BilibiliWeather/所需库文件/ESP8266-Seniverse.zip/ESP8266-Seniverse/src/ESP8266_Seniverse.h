#ifndef _ESP8266_SENIVERSE_H_
#define _ESP8266_SENIVERSE_H_

#include "WeatherNow.h"
#include "Forecast.h"
#include "LifeInfo.h"
#endif
